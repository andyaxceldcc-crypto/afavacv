# Sistema de Streaming y Suscripción (PHP + MySQL)

Repositorio listo para subir a GitHub con la estructura exacta para tu plataforma de streaming con panel de control y sistema de pagos.

## Estructura del Proyecto
- `db.php` - Conexión segura a la base de datos usando PDO.
- `login.php` - Validación de inicio de sesión conectada a MySQL.
- `pago.php` - Pasarela de pago simulada protegida por sesiones.
- `database.sql` - Script completo para crear las tablas en la base de datos.

## Instrucciones de Instalación
1. Clona o descarga este repositorio en tu servidor local (ej. `htdocs` en XAMPP) o en tu hosting.
2. Importa el archivo `database.sql` en tu gestor de base de datos MySQL (phpMyAdmin, etc.).
3. Configura tus credenciales de base de datos en `db.php` si es necesario (usuario, contraseña, nombre de la BD).
4. Abre `login.php` en tu navegador.
