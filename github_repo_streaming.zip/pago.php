<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$mensaje = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tarjeta = trim($_POST['card_number']);
    if (strlen($tarjeta) >= 16) {
        $mensaje = '¡Pago procesado con éxito! Tu cuenta está activa.';
    } else {
        $mensaje = 'Número de tarjeta inválido.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pasarela de Pago</title>
    <style>
        body { font-family: Arial, sans-serif; background: #0f172a; color: #f8fafc; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .container { background: #1e293b; padding: 30px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.3); width: 380px; text-align: center; }
        h2 { margin-bottom: 20px; color: #38bdf8; }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #475569; background: #0f172a; color: #fff; border-radius: 6px; box-sizing: border-box; }
        button { background: #10b981; color: #fff; font-weight: bold; border: none; padding: 12px; width: 100%; border-radius: 6px; cursor: pointer; font-size: 16px; margin-top: 15px; }
        button:hover { background: #059669; }
        .success { color: #34d399; font-size: 14px; margin-top: 10px; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h2>Pasarela de Pago</h2>
    <p style="font-size: 14px; color: #94a3b8;">Hola, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
    <form method="POST" action="">
        <input type="text" name="card_name" placeholder="Nombre en la tarjeta" required>
        <input type="text" name="card_number" placeholder="Número de tarjeta (16 dígitos)" maxlength="16" required>
        <input type="text" name="card_expiry" placeholder="MM/AA" maxlength="5" required>
        <input type="password" name="card_cvv" placeholder="CVV" maxlength="4" required>
        <button type="submit">Pagar Suscripción</button>
        <?php if(!empty($mensaje)): ?>
            <div class="success"><?php echo $mensaje; ?></div>
        <?php endif; ?>
    </form>
</div>
</body>
</html>