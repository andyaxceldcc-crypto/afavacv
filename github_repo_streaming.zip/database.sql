CREATE DATABASE IF NOT EXISTS sistema_streaming;
USE sistema_streaming;

-- Tabla de Usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de Contenido / Películas con enlace largo de hasta 40,000 caracteres
CREATE TABLE IF NOT EXISTS movies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    enlace_largo VARCHAR(40000) NOT NULL,
    is_premium BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertar usuario administrador de prueba
INSERT INTO usuarios (nombre, email) 
VALUES ('Dueño', 'dueno@example.com')
ON DUPLICATE KEY UPDATE email=email;

-- Insertar contenido de prueba
INSERT INTO movies (title, enlace_largo, is_premium) 
VALUES ('Mi Video Principal', 'https://tu-enlace-gigante-o-codigo-embed-de-mas-de-caracteres...', TRUE);
